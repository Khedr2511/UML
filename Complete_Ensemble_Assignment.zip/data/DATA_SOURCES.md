# Input datasets

- `train-data.csv` and `test-data.csv`: user-supplied Used Cars Price Prediction data, https://www.kaggle.com/datasets/avikasliwal/used-cars-price-prediction . The test file has no target labels.
- `creditcard.csv`: reassembled from all four user-uploaded parts of `archive.zip`, in `aa`, `ab`, `ac`, `ad` order. ZIP CRC validation passed before extraction. Source: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud . Original shape: 284,807 × 31; fraud count: 492; exact duplicate rows: 1,081; missing values: zero. Duplicate removal occurs before splitting in the notebook.

`input_manifest.json` records file sizes and SHA-256 checksums of the exact inputs used. The large fraud CSV remains in the workspace and is omitted from the submission ZIP to keep the package small. Use the Kaggle source or your original extracted file when rerunning elsewhere.
