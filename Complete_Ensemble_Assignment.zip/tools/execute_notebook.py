import os,sys,time,tempfile
from pathlib import Path
os.environ.setdefault('JUPYTER_DATA_DIR',str(Path(sys.prefix) / 'share' / 'jupyter'))
os.environ.setdefault('IPYTHONDIR',str(Path(tempfile.gettempdir()) / 'ensemble-assignment-ipython'))
os.environ.setdefault('JUPYTER_RUNTIME_DIR','/tmp/assignment-jupyter-runtime')
os.environ.setdefault('MPLCONFIGDIR','/tmp/assignment-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/assignment-cache')
os.environ['OMP_NUM_THREADS']='2'
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['MKL_NUM_THREADS']='2'
import nbformat
from nbclient import NotebookClient
p=Path(sys.argv[1]).resolve()
nb=nbformat.read(p,as_version=4)
start=time.perf_counter()
def on_cell_start(cell, cell_index, **kwargs):
 if cell.cell_type=='code': print(f'Cell {cell_index}: {cell.source.splitlines()[0][:90]}',flush=True)
def on_cell_complete(cell, cell_index, **kwargs):
 nbformat.write(nb,p)
client=NotebookClient(nb,timeout=1800,kernel_name='python3',resources={'metadata':{'path':str(p.parent)}},on_cell_start=on_cell_start,on_cell_complete=on_cell_complete)
try:
 client.execute()
finally:
 nbformat.write(nb,p)
print(f'Executed {p.name} in {time.perf_counter()-start:.1f}s',flush=True)
