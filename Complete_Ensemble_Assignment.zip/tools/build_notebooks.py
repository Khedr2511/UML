from pathlib import Path
import nbformat as nbf
ROOT=Path(__file__).resolve().parents[1]

def notebook(name, cells):
    nb=nbf.v4.new_notebook(cells=[nbf.v4.new_markdown_cell(t) if k=='md' else nbf.v4.new_code_cell(t) for k,t in cells])
    nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.12'}}
    nbf.write(nb,ROOT/name)

imports='''import os
os.environ.setdefault("MPLCONFIGDIR", "/tmp/assignment-matplotlib")
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
from pathlib import Path
import json, time, platform, hashlib, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn
from IPython.display import display, Markdown
from sklearn.base import clone
from sklearn.model_selection import train_test_split, GridSearchCV, KFold, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import LinearSVC
from sklearn.ensemble import (RandomForestRegressor, RandomForestClassifier,
    HistGradientBoostingRegressor, HistGradientBoostingClassifier,
    StackingRegressor, StackingClassifier)
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
    precision_score, recall_score, f1_score, roc_auc_score, average_precision_score,
    precision_recall_curve, ConfusionMatrixDisplay, RocCurveDisplay, PrecisionRecallDisplay)
SEED = 42
np.random.seed(SEED)
ROOT = Path.cwd()
if not (ROOT / "data").exists() and (ROOT / "UML" / "data").exists():
    ROOT = ROOT / "UML"
DATA = ROOT / "data"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")
print({"python": platform.python_version(), "numpy": np.__version__,
       "pandas": pd.__version__, "scikit-learn": sklearn.__version__})
'''
car=[('md','''# Used Car Price Prediction
## 1. Title & Introduction
Predict used-car prices from vehicle characteristics using the mandatory [Kaggle dataset](https://www.kaggle.com/datasets/avikasliwal/used-cars-price-prediction). Prices are in **lakh INR** (one lakh = 100,000 INR). We compare three individual regressors with bagging, boosting, and out-of-fold stacking.

The supplied `test-data.csv` is an **unlabeled prediction set**, not an evaluation set. We reserve 20% of the labeled data for the final test and 20% for validation; 60% is used for tuning. All six final models use the identical held-out test rows. The preferred ensemble is selected using validation RMSE before any test results are computed.

Run all cells from this notebook's directory. Model training is required; no downloaded pretrained models are used. Small, explicit grids and three-fold CV keep runtime practical on a CPU. Seeds are fixed, though exact timings and small numerical differences depend on hardware.'''),('md','## 2. Import Libraries'),('code',imports),('md','''## 3. Data Loading & Exploration
Keep the original row ID for the unlabeled submission, then remove it from modeling. Remove exact duplicate labeled records before splitting to avoid identical records crossing partitions. Initial inspection reports the whole file's schema; detailed EDA uses training rows only.'''),('code','''raw = pd.read_csv(DATA / "train-data.csv", index_col=0)
external = pd.read_csv(DATA / "test-data.csv", index_col=0)
assert "Price" in raw and "Price" not in external
print("Labeled shape:", raw.shape, "Unlabeled shape:", external.shape)
display(raw.head(), raw.dtypes.to_frame("dtype"))
print("Exact duplicate rows removed:", int(raw.duplicated().sum()))
raw = raw.drop_duplicates().reset_index(drop=True)
assert raw["Price"].notna().all() and (raw["Price"] > 0).all()
X = raw.drop(columns="Price")
y = raw["Price"]
X_dev, X_test, y_dev, y_test = train_test_split(X, y, test_size=.2, random_state=SEED)
X_train, X_val, y_train, y_val = train_test_split(X_dev, y_dev, test_size=.25, random_state=SEED)
print("Train / validation / test:", len(X_train), len(X_val), len(X_test))
display(X_train.describe(include="all").T)
display(X_train.isna().sum().sort_values(ascending=False).to_frame("training_missing"))
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
sns.histplot(y_train, bins=50, ax=axes[0]); axes[0].set_title("Training prices (lakh INR)")
sns.histplot(np.log1p(y_train), bins=40, ax=axes[1]); axes[1].set_title("Log-transformed training prices")
sns.scatterplot(x=X_train["Year"], y=y_train, alpha=.3, ax=axes[2])
axes[2].set_title("Model year and training price"); axes[2].set_ylabel("Price (lakh INR)")
plt.tight_layout(); plt.show()
q1, q3 = y_train.quantile([.25,.75]); iqr = q3-q1
print("Training price outliers under 1.5 IQR rule:", int(((y_train<q1-1.5*iqr)|(y_train>q3+1.5*iqr)).sum()))
fig, ax = plt.subplots(figsize=(9,4))
sns.boxplot(x=X_train["Transmission"], y=y_train, ax=ax)
ax.set_title("Training price by transmission: expensive cars retained")
plt.show()
'''),('md','''## 4. Data Preprocessing
Extract numeric values from mileage, engine, and power strings; record the mileage unit to distinguish km/kg from km/l. Zeros for engine, mileage, power, or seats represent unusable specifications and become missing. Derive brand and vehicle age using a fixed **2019 dataset-era reference year**, and log-transform nonnegative kilometers driven. These are deterministic row-wise operations and learn no statistics.

Drop `Name` after extracting brand because individual model names create many rare categories. Drop `New_Price`: it is mostly missing and may not be available at prediction time. Keep plausible high prices and odometer outliers rather than removing test observations based on learned cutoffs. A log target reduces skew, but training in log space may trade high-price accuracy for relative accuracy. We always report metrics in the original units and inspect residuals.

Median imputation and standardization of numeric features, and modal imputation plus one-hot encoding of categories, are fitted **inside each CV fold**. Categories occurring fewer than 10 times are pooled; unseen categories are handled at prediction. Scaling supports linear regression and distance-based KNN; trees do not require it. No fitted transformation touches validation/test data during tuning.'''),('code','''def engineer(frame):
    out = frame.copy()
    out["Brand"] = out["Name"].str.split().str[0].str.lower()
    out["Age"] = 2019 - pd.to_numeric(out["Year"], errors="coerce")
    out["Mileage_Unit"] = out["Mileage"].str.extract(r"(km/kg|kmpl)", expand=False)
    for col in ["Mileage", "Engine", "Power"]:
        out[col] = pd.to_numeric(out[col].astype(str).str.extract(r"([0-9.]+)", expand=False), errors="coerce")
        out.loc[out[col] <= 0, col] = np.nan
    out["Seats"] = pd.to_numeric(out["Seats"], errors="coerce").replace(0, np.nan)
    km = pd.to_numeric(out["Kilometers_Driven"], errors="coerce")
    out["Log_Kilometers"] = np.log1p(km.where(km >= 0))
    return out.drop(columns=["Name", "New_Price", "Year", "Kilometers_Driven"])

Xt, Xv, Xte, Xd = map(engineer, [X_train, X_val, X_test, X_dev])
num = Xt.select_dtypes(include="number").columns.tolist()
cat = Xt.select_dtypes(exclude="number").columns.tolist()
preprocessor = ColumnTransformer([
    ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), num),
    ("categorical", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", min_frequency=10, sparse_output=False))]), cat)
])
def regressor(estimator):
    return TransformedTargetRegressor(
        regressor=Pipeline([("preprocess", clone(preprocessor)), ("model", estimator)]),
        func=np.log1p, inverse_func=np.expm1)
cv = KFold(n_splits=3, shuffle=True, random_state=SEED)
'''),('md','''## 5. Individual Models
**Decision Tree** captures nonlinear interactions but can have high variance; depth and leaf-size controls regularize it. **Linear Regression** provides a low-variance additive baseline in log-price space. **KNN** tests a local similarity assumption; neighbor count and distance weighting control smoothing. All preprocessing and target transformations belong to the estimator so CV remains isolated.

We tune using three-fold CV RMSE in original price units on training data. The linear model has no substantive regularization parameter, so its single configuration is still cross-validated. Report CV mean, standard deviation, validation MAE/RMSE/R², and grid-search time. Grid-search time includes all candidate/fold fits and differs from final fit time.'''),('code','''specs = {
    "Decision Tree": (regressor(DecisionTreeRegressor(random_state=SEED)),
        {"regressor__model__max_depth": [6, 12], "regressor__model__min_samples_leaf": [3, 10]}),
    "Linear Regression": (regressor(LinearRegression()), {}),
    "KNN": (regressor(KNeighborsRegressor(n_jobs=2)),
        {"regressor__model__n_neighbors": [5, 15], "regressor__model__weights": ["uniform", "distance"]})
}
searches, validation_rows = {}, []
def tune(name, estimator, grid):
    start = time.perf_counter()
    search = GridSearchCV(estimator, grid, scoring="neg_root_mean_squared_error", cv=cv, n_jobs=2, error_score="raise")
    search.fit(Xt, y_train)
    elapsed = time.perf_counter() - start
    pred = search.predict(Xv)
    idx = search.best_index_
    validation_rows.append({"Model": name, "CV_RMSE": -search.best_score_,
        "CV_SD": search.cv_results_["std_test_score"][idx],
        "Validation_MAE": mean_absolute_error(y_val, pred),
        "Validation_RMSE": np.sqrt(mean_squared_error(y_val, pred)),
        "Validation_R2": r2_score(y_val, pred), "Search_seconds": elapsed})
    searches[name] = search
    print(name, search.best_params_, f"search={elapsed:.1f}s", flush=True)
for name, (estimator, grid) in specs.items():
    tune(name, estimator, grid)
display(pd.DataFrame(validation_rows))
'''),('md','''## 6. Ensemble Models
### Bagging: Random Forest
Each tree fits a bootstrap sample drawn with replacement. Averaging weakly correlated trees reduces variance relative to a single tree. Random feature subsets decorrelate trees. We vary both tree count and maximum depth; more trees stabilize predictions but increase computation.
### Boosting: Histogram Gradient Boosting
Trees are trained sequentially to correct the current loss gradient. Learning rate controls update size, iteration count controls capacity, and leaf size regularizes. We use a fixed grid with early stopping disabled so iteration comparisons are explicit. A validation curve below shows the effect of boosting rounds; it is not a test-set learning curve.
### Stacking
Three diverse base learners (linear regression, decision tree, KNN) produce **out-of-fold predictions** in three inner folds. Ridge combines these predictions with regularization. Each base learner owns its preprocessing pipeline, preventing leakage even in inner folds. The outer search evaluates the entire stack; no prefit mode is used. We stack log-price predictions under the common target transform; the final output is back-transformed to lakh INR. Base-model hyperparameters were selected earlier on training data, so outer stacking CV is conditional on those choices rather than a fully nested estimate of the complete selection procedure. Independent validation and test results provide the final checks.'''),('code','''rf = regressor(RandomForestRegressor(random_state=SEED, min_samples_leaf=2, n_jobs=1))
tune("Random Forest", rf, {"regressor__model__n_estimators": [60, 120], "regressor__model__max_depth": [12, None]})
boost = regressor(HistGradientBoostingRegressor(random_state=SEED, early_stopping=False, max_leaf_nodes=15))
tune("Gradient Boosting", boost, {"regressor__model__max_iter": [80, 160], "regressor__model__learning_rate": [.05, .1]})
# Base pipelines consume the log target passed by the outer target transformer.
base = [("linear", clone(searches["Linear Regression"].best_estimator_.regressor)),
        ("tree", clone(searches["Decision Tree"].best_estimator_.regressor)),
        ("knn", clone(searches["KNN"].best_estimator_.regressor))]
stack = TransformedTargetRegressor(
    regressor=StackingRegressor(estimators=base, final_estimator=Ridge(),
                               cv=KFold(3, shuffle=True, random_state=SEED), n_jobs=1),
    func=np.log1p, inverse_func=np.expm1)
tune("Stacking", stack, {"regressor__final_estimator__alpha": [.1, 10.]})
validation = pd.DataFrame(validation_rows).set_index("Model")
ensemble_names = ["Random Forest", "Gradient Boosting", "Stacking"]
selected = validation.loc[ensemble_names, "Validation_RMSE"].idxmin()
print("Ensemble selected BEFORE test evaluation:", selected)
display(validation.sort_values("Validation_RMSE"))
validation.to_csv(RESULTS / "car_validation.csv")
# CV response surface: effect of both bagging hyperparameters.
rf_cv = pd.DataFrame(searches["Random Forest"].cv_results_)
display(rf_cv[["param_regressor__model__n_estimators", "param_regressor__model__max_depth", "mean_test_score", "std_test_score"]])
b = searches["Gradient Boosting"].best_estimator_
transformed_val = b.regressor_.named_steps["preprocess"].transform(Xv)
curve = [np.sqrt(mean_squared_error(y_val, np.expm1(p)))
         for p in b.regressor_.named_steps["model"].staged_predict(transformed_val)]
plt.plot(np.arange(1,len(curve)+1),curve)
plt.xlabel("Boosting iteration"); plt.ylabel("Validation RMSE (lakh INR)")
plt.title("Boosting performance as iterations increase"); plt.show()
'''),('md','''## 7. Model Evaluation
Lock all model choices, refit each selected configuration on training + validation data, and evaluate once on the common untouched test set. Report MAE, RMSE, R², fit time, and training-only CV performance. Test outcomes characterize generalization; they are not used to retune or choose the preferred ensemble. Final training times include preprocessing and fitting but exclude prediction and earlier search.'''),('code','''final_models, test_predictions, rows = {}, {}, []
for name, search in searches.items():
    estimator = clone(search.best_estimator_)
    start = time.perf_counter(); estimator.fit(Xd, y_dev); elapsed = time.perf_counter()-start
    pred = estimator.predict(Xte)
    final_models[name], test_predictions[name] = estimator, pred
    rows.append({"Model":name, "MAE":mean_absolute_error(y_test,pred),
        "RMSE":np.sqrt(mean_squared_error(y_test,pred)), "R2":r2_score(y_test,pred),
        "Fit_seconds":elapsed, "CV_RMSE":validation.loc[name,"CV_RMSE"],
        "CV_SD":validation.loc[name,"CV_SD"]})
comparison = pd.DataFrame(rows).set_index("Model").sort_values("RMSE")
display(comparison)
comparison.to_csv(RESULTS / "car_test_comparison.csv")
fig, axes = plt.subplots(1,2,figsize=(13,4))
comparison["RMSE"].plot.barh(ax=axes[0], title="Common test RMSE (lower is better)")
axes[0].set_xlabel("RMSE (lakh INR)")
comparison["Fit_seconds"].plot.barh(ax=axes[1], title="Final fit time")
axes[1].set_xlabel("Seconds"); plt.tight_layout(); plt.show()
pred = test_predictions[selected]; residual = y_test.to_numpy()-pred
fig, axes = plt.subplots(1,3,figsize=(16,4))
axes[0].scatter(y_test,pred,alpha=.45)
lims=[min(y_test.min(),pred.min()),max(y_test.max(),pred.max())]
axes[0].plot(lims,lims,"r--"); axes[0].set(xlabel="Actual price",ylabel="Predicted price",title=selected)
axes[1].scatter(pred,residual,alpha=.45); axes[1].axhline(0,color="r",linestyle="--")
axes[1].set(xlabel="Predicted price",ylabel="Actual − predicted",title="Residuals (lakh INR)")
sns.histplot(residual,bins=40,ax=axes[2]); axes[2].set_title("Test residual distribution")
plt.tight_layout(); plt.show()
errors = X_test.copy(); errors["Actual"] = y_test; errors["Predicted"] = pred
errors["Absolute_error"] = np.abs(residual)
display(errors.sort_values("Absolute_error",ascending=False).head(10))
# Training-fit tree importances: avoids reusing test data for feature selection.
forest = final_models["Random Forest"].regressor_
importance = pd.Series(forest.named_steps["model"].feature_importances_,
    index=forest.named_steps["preprocess"].get_feature_names_out()).sort_values()
importance.tail(15).plot.barh(figsize=(9,5),title="Random Forest impurity importance")
plt.xlabel("Importance (not causal)"); plt.tight_layout(); plt.show()
# Refit only the validation-selected ensemble on all labeled records for delivery.
production = clone(searches[selected].best_estimator_).fit(engineer(X),y)
submission = pd.DataFrame({"Price":production.predict(engineer(external))},index=external.index)
submission.index.name="Id"
submission.to_csv(RESULTS / "used_car_test_predictions.csv")
print("Exported",len(submission),"unlabeled car-price predictions; no evaluation claim for these rows.")
'''),('md','''## 8. Discussion & Interpretation
The following interpretation is computed from this run. RMSE emphasizes expensive mistakes; MAE represents typical absolute error. A smaller log-space training loss does not guarantee the best original-price RMSE. Impurity importances favor features with many possible splits and should be treated as association rather than causation.'''),('code','''best = comparison.loc[selected]
rf_error = comparison.loc["Random Forest","RMSE"]
tree_error = comparison.loc["Decision Tree","RMSE"]
fastest = comparison["Fit_seconds"].idxmin()
display(Markdown(f"""**Validation-selected ensemble: {selected}.** Its test MAE is **{best.MAE:.3f} lakh INR**, RMSE **{best.RMSE:.3f}**, and R² **{best.R2:.3f}**. This choice was fixed using validation RMSE; the lowest test RMSE in this particular run belongs to **{comparison.RMSE.idxmin()}**.

Random Forest test RMSE is {rf_error:.3f}, versus {tree_error:.3f} for a single tree (difference {rf_error-tree_error:+.3f}). Tree averaging reduces variance, although the measured difference also reflects tuned depth/leaf settings. Boosting builds nonlinear corrections and can reduce underfitting; excess rounds or large learning rates can overfit. Stacking benefits when base-model errors differ, but extra fitting and correlated predictions may erase the benefit.

The fastest final fit was **{fastest}**; compare the measured fit times with the CV search cost. Forest fitting scales approximately with tree count and sample count times tree-search cost. Boosting is sequential across rounds. Stacking nests multiple fits per fold, while KNN has cheap fitting but potentially expensive prediction. Timing reflects this machine and does not establish universal complexity rankings.

Linear regression imposes stronger structural bias; deep trees have higher variance. The validation/CV/test gaps and residual plots provide evidence of generalization, but a single seed cannot establish statistical significance. High-value cars and rare categories can be difficult, and a random split does not prove performance on future market years or unseen regions. Use prediction intervals and external temporal validation before deployment. An estimated price is decision support, not a guaranteed resale value.
"""))
if (RESULTS/"fraud_test_comparison.csv").exists():
    fraud=pd.read_csv(RESULTS/"fraud_test_comparison.csv")
    display(Markdown(f"Fraud results are also available: highest observed test AP = **{fraud.AP.max():.4f}**. AP cannot be compared numerically with price RMSE; their units and business losses differ."))
'''),('md','''## 9. Conclusion
This workflow provides train-only preprocessing, three baseline algorithms, all three required ensemble families, nested out-of-fold stacking, CV tuning, validation curves, one common final test set, residual analysis, feature importance, and predictions for the supplied unlabeled file. The executed comparison and interpretation above identify the empirical winner without assuming stacking always wins.

### Cross-project discussion
Fraud detection is a rare-event ranking and decision problem: average precision, recall, alert precision, and threshold-dependent false positives matter more than accuracy. Price regression predicts a continuous amount: MAE, RMSE, and R² describe different aspects of error. Bagging controls variance in both; boosting can reduce bias but needs regularization; stacking helps only when diverse out-of-fold predictions contain complementary information. Fraud uses stratification and class weighting; car prices need mixed-feature encoding, unit parsing, and skew management. Neither project supports a universal ensemble ranking.

## 10. References
- [Used Cars Price Prediction, Kaggle](https://www.kaggle.com/datasets/avikasliwal/used-cars-price-prediction)
- [scikit-learn: ensemble methods](https://scikit-learn.org/stable/modules/ensemble.html)
- [scikit-learn: preprocessing and leakage](https://scikit-learn.org/stable/common_pitfalls.html)
- [scikit-learn: model evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html)
- Breiman (2001), Random Forests; Wolpert (1992), Stacked Generalization; Friedman (2001), Greedy Function Approximation: A Gradient Boosting Machine.
''')]
notebook('Used_Car_Price_Prediction.ipynb',car)
fraud=[('md','''# Credit Card Fraud Detection
## 1. Title & Introduction
Use the mandatory [ULB credit-card fraud dataset](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud) to identify fraudulent transactions. `Class=1` denotes fraud. `V1`–`V28` are anonymized PCA components; `Time` and `Amount` are the other original features.

**Execution status:** all cells have been executed successfully on the mandatory dataset, recovered from the four user-uploaded ZIP parts. ZIP integrity was verified before extraction. Original data: 284,807 transactions, 492 fraud cases, 31 columns, no missing values. The 1,081 exact duplicate rows are removed before splitting. Results, charts, and interpretations below are from this real-data run.

The workflow compares Decision Tree, Logistic Regression, and a linear SVM with Random Forest bagging, histogram gradient boosting, and out-of-fold stacking. Accuracy is not the primary metric: a detector predicting every transaction as legitimate would appear accurate but miss every fraud. We tune using average precision (AP), report ROC-AUC and threshold metrics, and explicitly analyze alert burden.

Use a stratified 60% training / 20% validation / 20% final-test split. All final models use the same test set. Validation selects thresholds and the preferred ensemble before test evaluation. The random split is an assignment benchmark; a real deployment requires chronological and customer-aware validation unavailable from anonymized records.'''),('md','## 2. Import Libraries'),('code',imports),('md','''## 3. Data Loading & Exploration
Load the full mandatory dataset, verify the expected schema, and remove exact duplicate records before splitting. No majority-class downsampling is applied to validation or test data. Detailed EDA uses training data. Dataset-level schema and counts describe provenance, not a source for tuning decisions.'''),('code','''candidates = [DATA / "creditcard.csv", DATA / "creditcard.csv.gz"]
path = next((p for p in candidates if p.exists()), None)
if path is None:
    raise FileNotFoundError("Mandatory dataset missing: put Kaggle creditcard.csv or creditcard.csv.gz in data/. The uploaded archive exceeded the transfer limit; no fraud results have been produced.")
df = pd.read_csv(path)
expected = {"Time", "Amount", "Class"} | {f"V{i}" for i in range(1,29)}
assert expected.issubset(df.columns), "Unexpected dataset schema"
assert set(df["Class"].dropna().unique()) == {0,1} and df["Class"].notna().all()
print("Original shape:", df.shape)
print("Exact duplicate rows removed:", int(df.duplicated().sum()))
df = df.drop_duplicates().reset_index(drop=True)
print("After deduplication:",df.shape)
display(df.head(), df.dtypes.to_frame("dtype"))
X, y = df.drop(columns="Class"), df["Class"].astype(int)
X_dev, X_test, y_dev, y_test = train_test_split(X,y,test_size=.2,stratify=y,random_state=SEED)
X_train, X_val, y_train, y_val = train_test_split(X_dev,y_dev,test_size=.25,stratify=y_dev,random_state=SEED)
for name,target in [("train",y_train),("validation",y_val),("test",y_test)]:
    print(name,len(target),"fraud count",int(target.sum()),"fraud proportion",target.mean())
display(X_train.describe().T, X_train.isna().sum().to_frame("training_missing"))
fig, axes = plt.subplots(1,3,figsize=(15,4))
sns.countplot(x=y_train,ax=axes[0]); axes[0].set_yscale("log"); axes[0].set_title("Training classes (log count)")
sns.histplot(x=np.log1p(X_train["Amount"]),hue=y_train.to_numpy(),bins=50,element="step",common_norm=False,ax=axes[1])
axes[1].set_title("Training log(1+Amount)")
sns.boxplot(x=y_train,y=X_train["Amount"],showfliers=False,ax=axes[2]); axes[2].set_title("Amount by class (fliers hidden only in plot)")
plt.tight_layout(); plt.show()
eda = X_train[["Amount","Time","V4","V10","V12","V14","V17"]].copy()
eda["Class"]=y_train
sns.heatmap(eda.corr(),cmap="coolwarm",center=0); plt.title("Training correlations (selected features)"); plt.show()
q1,q3=X_train["Amount"].quantile([.25,.75]); cutoff=q3+1.5*(q3-q1)
print("Training Amount upper-IQR outliers:",int((X_train.Amount>cutoff).sum()))
'''),('md','''## 4. Data Preprocessing
Use median imputation and StandardScaler fitted within each training fold. All features are numeric; categorical encoding is unnecessary. Retain transaction-amount outliers because rare extreme events may carry fraud signal. Add log amount and deterministic daily sine/cosine time features, preserving raw `Time` and `Amount`. The daily time representation is exploratory: elapsed seconds do not reveal a verified clock-time origin.

**Class imbalance:** set `class_weight='balanced'` for trees, Logistic Regression, SVM, boosting, and the stacking meta-learner. Weights are recomputed using each fit's labels, including inner folds. Random Forest uses `balanced_subsample`, recomputed for each bootstrap sample. This avoids global resampling and preserves natural validation/test prevalence. Weighted scores are not assumed to be calibrated fraud probabilities.

The PCA components were supplied by the dataset publisher; the original PCA fit cannot be audited or refitted from these anonymized features. All transformations introduced here remain fold-local. Three-fold stratified CV keeps fraud present in folds. Full-data linear models and constrained tree grids are CPU-friendly relative to kernel SVMs; no silent sample-size cap is used.'''),('code','''def engineer(frame):
    out=frame.copy()
    out["Log_Amount"]=np.log1p(out["Amount"].where(out["Amount"]>=0))
    phase=2*np.pi*out["Time"]/86400
    out["Time_sin"]=np.sin(phase); out["Time_cos"]=np.cos(phase)
    return out
Xt,Xv,Xte,Xd=map(engineer,[X_train,X_val,X_test,X_dev])
preprocessor=Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler())])
def classifier(estimator):
    return Pipeline([("preprocess",clone(preprocessor)),("model",estimator)])
cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=SEED)
def scores(model, features):
    if hasattr(model,"predict_proba"):
        return model.predict_proba(features)[:,1]
    return model.decision_function(features)
def choose_threshold(labels, score):
    precision,recall,thresholds=precision_recall_curve(labels,score)
    f1=2*precision[:-1]*recall[:-1]/np.maximum(precision[:-1]+recall[:-1],1e-12)
    return float(thresholds[int(np.argmax(f1))])
def classification_metrics(labels, score, threshold):
    pred=(score>=threshold).astype(int)
    return {"Precision":precision_score(labels,pred,zero_division=0),
        "Recall":recall_score(labels,pred,zero_division=0),
        "F1":f1_score(labels,pred,zero_division=0),
        "ROC_AUC":roc_auc_score(labels,score),"AP":average_precision_score(labels,score),
        "False_positives":int(((pred==1)&(np.asarray(labels)==0)).sum()),
        "Missed_fraud":int(((pred==0)&(np.asarray(labels)==1)).sum())}
'''),('md','''## 5. Individual Models
**Decision Tree** learns nonlinear fraud rules but can overfit rare events; tune depth and minimum leaf size. **Logistic Regression** is an interpretable linear score with L2 regularization; tune inverse regularization `C`. **Linear SVM** finds a margin-based boundary; `C` controls the margin/error trade-off. LinearSVC is the scalable linear SVM variant, not an RBF SVC; decision scores support ROC-AUC and AP without expensive probability calibration.

GridSearchCV optimizes AP using training folds only. For each chosen configuration, choose a validation threshold maximizing F1. F1 assigns equal importance to precision and recall, an explicit assignment assumption rather than a bank-specific cost model. Report CV standard deviations and validation results. Tuning and threshold optimization on finite data introduce uncertainty; the untouched test supplies the final estimate.'''),('code','''specs={
 "Decision Tree":(classifier(DecisionTreeClassifier(class_weight="balanced",random_state=SEED)),
     {"model__max_depth":[5,10],"model__min_samples_leaf":[5,20]}),
 "Logistic Regression":(classifier(LogisticRegression(class_weight="balanced",max_iter=2000,random_state=SEED)),
     {"model__C":[.1,1.]}),
 "Linear SVM":(classifier(LinearSVC(class_weight="balanced",dual=False,max_iter=10000,random_state=SEED)),
     {"model__C":[.1,1.]})
}
searches,thresholds,validation_rows={}, {}, []
def tune(name,estimator,grid):
    start=time.perf_counter()
    search=GridSearchCV(estimator,grid,scoring="average_precision",cv=cv,n_jobs=2,error_score="raise")
    search.fit(Xt,y_train)
    elapsed=time.perf_counter()-start
    score=scores(search.best_estimator_,Xv)
    threshold=choose_threshold(y_val,score)
    idx=search.best_index_
    row={"Model":name,"CV_AP":search.best_score_,"CV_SD":search.cv_results_["std_test_score"][idx],
         "Search_seconds":elapsed,"Threshold":threshold,**classification_metrics(y_val,score,threshold)}
    searches[name]=search; thresholds[name]=threshold; validation_rows.append(row)
    print(name,search.best_params_,f"search={elapsed:.1f}s",flush=True)
for name,(estimator,grid) in specs.items():
    tune(name,estimator,grid)
display(pd.DataFrame(validation_rows))
'''),('md','''## 6. Ensemble Models
### Bagging: Random Forest
Each tree learns from a bootstrap sample drawn with replacement; random feature selection decorrelates trees. Averaging reduces the variance of a single tree. Compare 60 versus 120 trees and depth 10 versus unrestricted, retaining leaf regularization. More trees cost additional fitting and prediction time.
### Boosting
Histogram Gradient Boosting fits trees sequentially to the negative loss gradient. Learning rate shrinks corrections, iteration count sets the number of rounds, and leaf count/size limit complexity. Class weighting emphasizes fraud loss. Explicitly disable early stopping so the grid and staged validation curve refer to exact boosting iterations.
### Stacking
A tree, Logistic Regression, and linear SVM contribute diverse nonlinear/probabilistic/margin scores. A regularized Logistic Regression meta-learner learns from **out-of-fold** predictions in three stratified inner folds. Base learners include their own preprocessing. `stack_method='auto'` uses probabilities when available and decision scores for LinearSVC. The meta-learner scales these columns inside its own pipeline; raw SVM scores and probabilities have different scales. Outer CV evaluates the complete nested estimator. Base hyperparameters are fixed before stacking; outer-stack CV is conditional on those training-set choices, so independent validation/test results remain the decisive generalization checks.'''),('code','''tune("Random Forest",classifier(RandomForestClassifier(class_weight="balanced_subsample",
     min_samples_leaf=2,random_state=SEED,n_jobs=1)),
     {"model__n_estimators":[60,120],"model__max_depth":[10,None]})
tune("Gradient Boosting",classifier(HistGradientBoostingClassifier(class_weight="balanced",
     early_stopping=False,max_leaf_nodes=15,min_samples_leaf=20,random_state=SEED)),
     {"model__max_iter":[80,160],"model__learning_rate":[.05,.1]})
base=[("tree",clone(searches["Decision Tree"].best_estimator_)),
      ("logistic",clone(searches["Logistic Regression"].best_estimator_)),
      ("svm",clone(searches["Linear SVM"].best_estimator_))]
meta=Pipeline([("scale",StandardScaler()),("lr",LogisticRegression(class_weight="balanced",max_iter=2000,random_state=SEED))])
stack=StackingClassifier(estimators=base,final_estimator=meta,
    cv=StratifiedKFold(3,shuffle=True,random_state=SEED),stack_method="auto",n_jobs=1)
tune("Stacking",stack,{"final_estimator__lr__C":[.1,1.]})
validation=pd.DataFrame(validation_rows).set_index("Model")
ensemble_names=["Random Forest","Gradient Boosting","Stacking"]
selected=validation.loc[ensemble_names,"AP"].idxmax()
print("Preferred ensemble selected BEFORE test evaluation:",selected)
display(validation.sort_values("AP",ascending=False))
validation.to_csv(RESULTS/"fraud_validation.csv")
rf_cv=pd.DataFrame(searches["Random Forest"].cv_results_)
display(rf_cv[["param_model__n_estimators","param_model__max_depth","mean_test_score","std_test_score"]])
b=searches["Gradient Boosting"].best_estimator_
transformed=b.named_steps["preprocess"].transform(Xv)
curve=[average_precision_score(y_val,p[:,1]) for p in b.named_steps["model"].staged_predict_proba(transformed)]
plt.plot(np.arange(1,len(curve)+1),curve)
plt.xlabel("Boosting iteration"); plt.ylabel("Validation average precision")
plt.title("Boosting iterations and fraud-ranking performance"); plt.show()
# Practical threshold trade-offs measured only on validation.
s=scores(searches[selected].best_estimator_,Xv)
threshold_grid=np.unique(np.r_[np.quantile(s,[.9,.95,.99,.995,.999]),thresholds[selected]])
tradeoff=pd.DataFrame([{"Threshold":t,**classification_metrics(y_val,s,t)} for t in threshold_grid])
display(tradeoff.sort_values("Threshold"))
'''),('md','''## 7. Model Evaluation
Freeze all hyperparameters, thresholds, and ensemble choice. Evaluate the fitted training-only models on the common held-out test set once. **Do not refit on validation before testing:** a refit can change score scales and invalidate validation-chosen SVM/probability thresholds. Report each model's training fit time by timing an identical deterministic training-only fit; use this refit for final prediction. Search time is reported separately. CV mean and SD are training-only AP.

AP is the requested precision–recall summary (average precision), rather than trapezoidal interpolation. A random ranking has expected precision near fraud prevalence. ROC-AUC measures ranking across both classes and can look strong despite low alert precision; consider both curves and actual confusion counts.'''),('code','''final_models,test_scores,rows={}, {}, []
for name,search in searches.items():
    estimator=clone(search.best_estimator_)
    start=time.perf_counter(); estimator.fit(Xt,y_train); elapsed=time.perf_counter()-start
    score=scores(estimator,Xte)
    final_models[name]=estimator; test_scores[name]=score
    rows.append({"Model":name,**classification_metrics(y_test,score,thresholds[name]),
        "Threshold":thresholds[name],"Fit_seconds":elapsed,
        "CV_AP":validation.loc[name,"CV_AP"],"CV_SD":validation.loc[name,"CV_SD"]})
comparison=pd.DataFrame(rows).set_index("Model").sort_values("AP",ascending=False)
display(comparison)
comparison.to_csv(RESULTS/"fraud_test_comparison.csv")
fig,axes=plt.subplots(1,3,figsize=(17,4))
comparison[["Precision","Recall","F1","AP"]].plot.barh(ax=axes[0]); axes[0].set_title("Common test performance")
comparison["Fit_seconds"].plot.barh(ax=axes[1]); axes[1].set(xlabel="Seconds",title="Final training time")
comparison["CV_AP"].plot.barh(xerr=comparison["CV_SD"],ax=axes[2]); axes[2].set_title("Training CV AP ± fold SD")
plt.tight_layout(); plt.show()
fig,axes=plt.subplots(2,3,figsize=(15,8))
for ax,name in zip(axes.flat,comparison.index):
    pred=(test_scores[name]>=thresholds[name]).astype(int)
    ConfusionMatrixDisplay.from_predictions(y_test,pred,display_labels=["Legitimate","Fraud"],ax=ax,colorbar=False)
    ax.set_title(name)
plt.tight_layout(); plt.show()
fig,axes=plt.subplots(1,2,figsize=(13,5))
for name in comparison.index:
    RocCurveDisplay.from_predictions(y_test,test_scores[name],name=name,ax=axes[0])
    PrecisionRecallDisplay.from_predictions(y_test,test_scores[name],name=name,ax=axes[1])
axes[0].plot([0,1],[0,1],"k--",label="Random ranking"); axes[0].legend(fontsize=8)
axes[1].axhline(y_test.mean(),color="k",linestyle="--",label="Fraud prevalence")
axes[1].legend(fontsize=8); axes[0].set_title("Test ROC curves"); axes[1].set_title("Test precision–recall curves")
plt.tight_layout(); plt.show()
forest=final_models["Random Forest"].named_steps["model"]
importance=pd.Series(forest.feature_importances_,index=Xt.columns).sort_values()
importance.tail(15).plot.barh(figsize=(8,5),title="Random Forest impurity importance")
plt.xlabel("Importance (association, not causation)"); plt.tight_layout(); plt.show()
pd.DataFrame({"Original_row":X_test.index,"Actual":y_test,
    "Selected_model_score":test_scores[selected],
    "Fraud_alert":(test_scores[selected]>=thresholds[selected]).astype(int)}).to_csv(RESULTS/"fraud_test_predictions.csv",index=False)
'''),('md','''## 8. Discussion & Interpretation
Feature importance is descriptive: anonymized PCA components cannot be translated directly into business reasons. Impurity importance is biased toward features with many possible split points and correlated components can share importance. No causal conclusions are justified.'''),('code','''best=comparison.loc[selected]
rf_ap=comparison.loc["Random Forest","AP"]; tree_ap=comparison.loc["Decision Tree","AP"]
display(Markdown(f"""The validation-selected ensemble is **{selected}**. At its validation-selected threshold, test precision is **{best.Precision:.3f}**, recall **{best.Recall:.3f}**, F1 **{best.F1:.3f}**, ROC-AUC **{best.ROC_AUC:.3f}**, and AP **{best.AP:.3f}**. It produces **{int(best.False_positives)} false alerts** and misses **{int(best.Missed_fraud)} frauds** in this test set. The highest observed test AP belongs to **{comparison.AP.idxmax()}**, which does not override the precommitted validation choice.

Random Forest AP is {rf_ap:.3f}, compared with {tree_ap:.3f} for a single tree (difference {rf_ap-tree_ap:+.3f}). Tree averaging targets high variance; boosting sequentially corrects errors to reduce bias; stacking can combine complementary boundaries but adds nested fits. No ensemble is guaranteed to outperform every baseline. Compare the actual AP, recall, and timing table rather than assuming a ranking from model complexity.

The fastest final fit was **{comparison.Fit_seconds.idxmin()}**. A linear model typically scales more favorably than a nonlinear kernel SVM on this large dataset. Forest time grows with tree count; boosting rounds are sequential, and stacking multiplies base fits across folds. CV/search time must be budgeted separately from a deployed prediction call.

Lowering thresholds usually increases recall and alert workload; the validation trade-off table quantifies that tension for this run. F1 is not a monetary objective. A real bank should estimate missed-fraud costs and review capacity, select thresholds on a representative validation stream, and monitor precision as prevalence drifts. Class-weighted probabilities require separate calibration before risk pricing. The small number of test frauds and a single split limit certainty; no statistical superiority is claimed from fold SD alone.
"""))
if (RESULTS/"car_test_comparison.csv").exists():
    cars=pd.read_csv(RESULTS/"car_test_comparison.csv")
    display(Markdown(f"The companion car experiment achieved a lowest observed test RMSE of **{cars.RMSE.min():.3f} lakh INR**. That regression error has different units and business meaning from fraud AP."))
'''),('md','''## 9. Conclusion
The workflow covers all three required ensemble families and three individual baselines, class imbalance, fold-local preprocessing, validation-only threshold selection, CV tuning, learning-by-iteration curves, test comparison, confusion matrices, and feature importance. All cells have been executed on the mandatory fraud dataset. The numerical findings, selected ensemble, test-set trade-offs, and interpretations are recorded above. Results describe this fixed split, not a guarantee of future fraud-detection performance.

### Cross-project discussion
Fraud is rare-event classification: optimize ranking with AP and inspect precision/recall at an operational threshold. Cars require continuous estimates: MAE reports typical absolute error, RMSE penalizes large misses, and R² compares with a constant prediction. Accuracy is misleading for fraud and undefined as an ordinary regression metric. Bagging reduces variance in either setting; boosting trades bias reduction against overfitting; stacking requires out-of-fold predictions to avoid optimistic meta-training. Feature handling differs: fraud features are numeric and anonymized, whereas vehicle data needs string parsing and categorical encoding. Results should be judged using the relevant business loss, never by comparing an AP value numerically with an RMSE.

## 10. References
- [Credit Card Fraud Detection, MLG–ULB, Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)
- [scikit-learn ensemble documentation](https://scikit-learn.org/stable/modules/ensemble.html)
- [Precision–recall metrics](https://scikit-learn.org/stable/modules/model_evaluation.html#precision-recall-f-measure-metrics)
- [Data leakage pitfalls](https://scikit-learn.org/stable/common_pitfalls.html)
- Breiman (2001), Random Forests; Wolpert (1992), Stacked Generalization; Friedman (2001), Greedy Function Approximation: A Gradient Boosting Machine.
''')]
notebook('Credit_Card_Fraud_Detection.ipynb',fraud)
