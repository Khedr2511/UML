# Ensemble Learning Assignment

Two separate, self-contained notebooks implementing the supplied assignment:

- `Used_Car_Price_Prediction.ipynb`: executed on the supplied Kaggle car-price files; includes outputs, charts, interpretation, model comparisons, and 1,234 unlabeled-file predictions.
- `Credit_Card_Fraud_Detection.ipynb`: executed on the required ULB credit-card dataset; includes all six models, measured results, ROC/PR curves, six confusion matrices, validation threshold analysis, and interpretation. The four uploaded ZIP parts were joined and integrity-checked successfully. Both required projects are complete.

## Run

Python 3.12 was used. From this directory:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python -m ipykernel install --prefix "$VIRTUAL_ENV" --name python3 --display-name 'Python 3'
python tools/execute_notebook.py Used_Car_Price_Prediction.ipynb
```

The execution utility saves outputs in the notebook and raises on failed cells. It uses two compute threads and a two-worker grid search. On a local machine you may alternatively open either notebook in Jupyter or VS Code and run all cells with the virtual-environment kernel. All estimator code is embedded in each notebook; no helper module imports are required.

### Required fraud data

Download **Credit Card Fraud Detection, MLG–ULB** from https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud and put `creditcard.csv` or `creditcard.csv.gz` in `data/`. Do not replace it with a different fraud dataset. Then execute:

```bash
python tools/execute_notebook.py Credit_Card_Fraud_Detection.ipynb
```

The dataset was recovered from the four uploaded archive parts and is present in this workspace. It is omitted from the submission ZIP to keep the download small. For a rerun elsewhere, supply the original Kaggle CSV at the path above. A gzip file is also read directly by pandas. The car test file does not contain `Price`: final model comparisons use a held-out split of the labeled car file, and predictions for the unlabeled file are exported separately.

## Measured car results

Gradient boosting was selected using validation RMSE, before inspecting test results. On the common untouched labeled-data test partition:

| Model | MAE (lakh INR) | RMSE (lakh INR) | R² |
|---|---:|---:|---:|
| Gradient Boosting | 1.475 | 3.623 | 0.893 |
| Random Forest | 1.590 | 3.885 | 0.877 |
| Stacking | 1.641 | 4.189 | 0.857 |
| KNN | 1.838 | 4.468 | 0.838 |
| Linear Regression | 1.803 | 4.581 | 0.829 |
| Decision Tree | 2.284 | 4.874 | 0.807 |

One lakh INR equals 100,000 INR. CSVs in `results/` contain full-precision scores, CV standard deviations, measured training/search times, and predictions. Execution completed without notebook errors. Both notebooks completed all seven code cells without errors on their required real datasets. Synthetic development-check metrics are excluded from this deliverable.


## Measured fraud results

The validation-selected ensemble is **Random Forest**. On the common untouched test partition, at its validation-selected F1 threshold:

- Precision: 0.9342
- Recall: 0.7474
- F1: 0.8304
- ROC-AUC: 0.9343
- Average precision (PR AUC summary): 0.8017
- False positives: 5
- Missed fraud: 24

| Model | Precision | Recall | F1 | ROC-AUC | AP |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.9342 | 0.7474 | 0.8304 | 0.9343 | 0.8017 |
| Gradient Boosting | 0.9706 | 0.6947 | 0.8098 | 0.9368 | 0.7465 |
| Logistic Regression | 0.8372 | 0.7579 | 0.7956 | 0.9694 | 0.6938 |
| Stacking | 0.8276 | 0.7579 | 0.7912 | 0.9693 | 0.6804 |
| Linear SVM | 0.7609 | 0.7368 | 0.7487 | 0.9689 | 0.6739 |
| Decision Tree | 0.8649 | 0.6737 | 0.7574 | 0.8936 | 0.6695 |

The test table is a final comparison, not a source for choosing thresholds or retuning. See `data/input_manifest.json` for the exact input checksums.

## Methodology

Each notebook follows the ten required sections. Three baselines and all three ensemble methods are included. Random Forest grids vary both tree count and depth; boosting grids vary iteration count and learning rate and include a staged validation curve. Stacking uses three base learners and out-of-fold meta-training with fold-local preprocessing. Hyperparameters use three-fold CV on training data; a separate validation set selects the ensemble. Final comparisons share one untouched test partition.

Car preprocessing parses units, engineers brand/age/log odometer features, imputes missing values, encodes categories, standardizes numeric inputs, and log-transforms the training target. All fitted preprocessing stays inside CV pipelines. High-price outliers remain in evaluation. Fraud uses class weights, stratified splits, AP tuning, and validation-only decision thresholds; its final models retain the training-only fit population so a refit does not change the score scale after threshold selection. CV fold SD is descriptive, not a confidence interval.

The car stack's outer CV is conditional on base hyperparameters selected earlier on training data; it is not a fully nested estimate of the whole hyperparameter-selection procedure. Independent validation and final test estimates are therefore emphasized. The same limitation is explained in the fraud notebook.

## Files and reproducibility

`data/` contains the two user-supplied car CSVs. `requirements.txt` records the tested direct dependencies. `tools/build_notebooks.py` is the source generator; running it regenerates both notebooks and clears their saved outputs, so use it only when intentionally rebuilding. The execution helper runs existing notebooks without regenerating them.

No credentials, private IDs, or author identity are needed. Add your name/student ID if required and review the explanations and results before submitting. Both real-data evaluations and conclusions are included. Review the notebook methodology and results before submission.
